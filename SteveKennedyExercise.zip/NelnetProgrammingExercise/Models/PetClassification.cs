﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NelnetProgrammingExercise.Models
{
    public enum PetClassification
    {
        Mammal,
        Arachnid,
        Fish,
        Bird,
        Reptile
    }
}
