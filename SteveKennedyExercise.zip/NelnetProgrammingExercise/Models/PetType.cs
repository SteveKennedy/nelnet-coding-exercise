﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NelnetProgrammingExercise.Models
{
    public enum PetType
    {
        Cat,
        Dog,
        Spider,
        Snake,
        Goldfish,
        Betta,
        Rat,
        Parrot,
        Canary
    }
}
