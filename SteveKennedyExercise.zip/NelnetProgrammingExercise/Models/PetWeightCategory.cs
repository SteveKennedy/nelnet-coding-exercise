﻿namespace NelnetProgrammingExercise.Models
{
    public enum PetWeightCategory
    {
        ExtraSmall,
        Small,
        Medium,
        Large,
        ExtraLarge
    }
}